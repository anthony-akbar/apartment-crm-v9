<?php $__env->startSection('content'); ?>
    <div class="intro-y flex flex-col sm:flex-row items-center p-5">
        <h2 class="text-lg font-medium mr-auto">Парковка</h2>
    </div>

    <div class="grid grid-cols-12 gap-5 mt-5 pt-5">

        <?php for($i=1; $i <= 95; $i++): ?>

        <a href="javascript:;" class="intro-y block">
            <div style="<?php echo e($i % 3 === 0 ? 'background-color: red; ' : ''); ?> <?php echo e($i % 5 === 0 ? 'background-color: yellow; ' : ''); ?> <?php echo e($i % 3 !== 0 && $i % 5 !== 0 ? 'background-color: green;' : ''); ?> <?php echo e($i % 3 !== 0 && $i % 5 !== 0 ? "" : "background-image: url('car.png'); "); ?> width: 75px; height: 150px; background-size: cover" class="rounded-md relative zoom-in">
                <span class="text-white font-medium" style="position: absolute; top: 79px; font-size: 24px; left: 35px; transform: translate(-50%, -50%)">
                    <?php echo e($i); ?>

                </span>
            </div>
        </a>

            <?php endfor; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Akbar\Projects\apartment-crm-v9\resources\views/parking/index.blade.php ENDPATH**/ ?>