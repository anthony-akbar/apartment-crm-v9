<!DOCTYPE html>
<html class="theme-4">
<head>
    <meta charset="utf-8">
    <link href="<?php echo e(asset('black-cut.png')); ?>" rel="shortcut icon">
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/app.css')); ?>"/>
    <title>Business House</title>
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body class="login">
<?php echo $__env->yieldContent('content'); ?>
<scripts src="<?php echo e(asset('dist/js/app.js')); ?>"></scripts>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\Development\Akbar\Projects\apartment-crm-v9\resources\views/layouts/app.blade.php ENDPATH**/ ?>