<!-- BEGIN: Data List -->
<div class="intro-y col-span-12 overflow-auto 2xl:overflow-visible">
    <table class="table table-report -mt-2">
        <thead>
        <tr>
            <th class="whitespace-nowrap">№</th>
            <th class="whitespace-nowrap">Ф.И.О.</th>
            <th class="text-center whitespace-nowrap">Статус</th>
            <th class="whitespace-nowrap">Квартира</th>
            <th class="text-center whitespace-nowrap">Действия</th>
        </tr>
        </thead>
        <tbody>

        <?php $__currentLoopData = $aptContracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="intro-x">
                <td class="w-40 !py-4"><a class="whitespace-nowrap"><?php echo e($contract->id); ?></a></td>
                <td class="w-40">
                    <a href="<?php echo e(route('contracts.apartments.show', $contract->id)); ?>" class="underline decoration-dotted font-medium whitespace-nowrap"><?php echo e($contract->client->firstname); ?> <?php echo e($contract->client->name); ?> <?php echo e($contract->client->fathersname ?? ''); ?></a>
                    <div class="text-slate-500 text-xs whitespace-nowrap mt-0.5"><?php echo e($contract->client->passportId); ?></div>
                </td>
                <td class="text-center">
                    <div class="flex items-center justify-center whitespace-nowrap text-success">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                             icon-name="check-square" data-lucide="check-square"
                             class="lucide lucide-check-square w-4 h-4 mr-2">
                            <polyline points="9 11 12 14 22 4"></polyline>
                            <path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"></path>
                        </svg>
                        <?php echo e($contract->status); ?>

                    </div>
                </td>
                <td>
                    <div class="whitespace-nowrap">№<?php echo e($contract->apartment->id); ?></div>
                    <div class="text-slate-500 text-xs whitespace-nowrap mt-0.5"><?php echo e($contract->apartment->square); ?> м²</div>
                </td>
                <td class="table-report__action">
                    <div class="flex justify-center items-center">
                        <a class="flex items-center text-primary whitespace-nowrap mr-5" href="<?php echo e(route('contracts.apartments.download', $contract->id)); ?>">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                 fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                 stroke-linejoin="round" icon-name="check-square" data-lucide="check-square"
                                 class="lucide lucide-check-square w-4 h-4 mr-1">
                                <polyline points="9 11 12 14 22 4"></polyline>
                                <path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"></path>
                            </svg>
                            Детали </a>
                        <a class="flex items-center text-primary whitespace-nowrap" href="javascript:;"
                           data-tw-toggle="modal" data-tw-target="#delete-confirmation-modal-<?php echo e($contract->id); ?>">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                 fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                 stroke-linejoin="round" icon-name="arrow-left-right" data-lucide="arrow-left-right"
                                 class="lucide lucide-arrow-left-right w-4 h-4 mr-1">
                                <polyline points="17 11 21 7 17 3"></polyline>
                                <line x1="21" y1="7" x2="9" y2="7"></line>
                                <polyline points="7 21 3 17 7 13"></polyline>
                                <line x1="15" y1="17" x2="3" y2="17"></line>
                            </svg>
                            Удалить </a>
                    </div>
                </td>
            </tr>
            <!-- BEGIN: Delete Confirmation Modal -->
            <div id="delete-confirmation-modal-<?php echo e($contract->id); ?>" class="modal" tabindex="-1" aria-hidden="true" style="">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-body p-0">
                            <div class="p-5 text-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" icon-name="x-circle" data-lucide="x-circle" class="lucide lucide-x-circle w-16 h-16 text-danger mx-auto mt-3"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>
                                <div class="text-3xl mt-5">Are you sure?</div>
                                <div class="text-slate-500 mt-2">
                                    Do you really want to delete these records?
                                    <br>
                                    This process cannot be undone.
                                </div>
                            </div>
                            <div class="px-5 pb-8 text-center">
                                <form method="post" action="<?php echo e(route('clients.delete', $contract->id)); ?>">
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>
                                    <a type="button" data-tw-dismiss="modal" class="btn btn-outline-secondary w-24 mr-1">Cancel</a>
                                    <button type="submit" class="btn btn-danger w-24">Delete</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END: Delete Confirmation Modal -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>
<!-- END: Data List -->
<!-- BEGIN: Pagination -->
<div class="intro-y col-span-12 flex flex-wrap sm:flex-row sm:flex-nowrap items-center">

    <div class="grid grid-cols-2">
        <div class="mt-10 grid-cols-1 text-center">
            
        </div>
    </div>

    
    <select class="w-20 form-select box mt-3 sm:mt-0">
        <option>10</option>
        <option>25</option>
        <option>35</option>
        <option>50</option>
    </select>
</div>
<!-- END: Pagination -->
<?php /**PATH D:\Development\Akbar\Projects\apartment-crm-v9\resources\views/contracts/apartments/table.blade.php ENDPATH**/ ?>