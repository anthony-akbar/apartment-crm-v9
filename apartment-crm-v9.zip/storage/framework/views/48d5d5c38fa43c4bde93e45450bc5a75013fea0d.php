<table style="border: 0.41rem solid black; vertical-align: text-top; font-size: 1rem; font-weight: bold">
    <thead>
    <tr>
        <th style="vertical-align: middle; text-align: center">№ п/п</th>
        <th style="vertical-align: middle; text-align: center">Дата внесения денежных средств</th>
        <th style="vertical-align: middle; text-align: center">Сумма денежных средств, подлежащая внесению (<?php echo e($currency === 'KGS' ? 'Сомах' : 'Долларах'); ?>)</th>
        <th style="vertical-align: middle; text-align: center">Оплачено</th>
    </tr>
    </thead>
    <tbody>

    <?php $__currentLoopData = $schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if($item->status === 'Перв.взнос'): ?>
            <tr style="height: 1.2cm">
                <td style="vertical-align: middle; text-align: center"></td>
                <td style="vertical-align: middle; text-align: center; width: 30%">Перв.взнос</td>
                <td style="vertical-align: middle; text-align: center; width: 30%"><?php echo e(number_format($item->amount, 0, '.', ' ')); ?> <?php echo e($currency === 'KGS' ? 'сом' : '$'); ?></td>
                <td style="vertical-align: middle; text-align: center; width: 40%"></td>
            </tr>
        <?php else: ?>
        <tr style="height: 1.2cm">
            <td style="vertical-align: middle; text-align: center"><?php echo e($key); ?></td>
            <td style="vertical-align: middle; text-align: center; width: 30%"><?php echo e(date("d.m.Y", strtotime($item->date_of_payment))); ?></td>
            <td style="vertical-align: middle; text-align: center; width: 30%"><?php echo e(number_format($item->amount, 0, '.', ' ')); ?> <?php echo e($currency === 'KGS' ? 'сом' : '$'); ?></td>
            <td style="vertical-align: middle; text-align: center; width: 40%"></td>
        </tr>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr style="height: 36px">
        <td style="vertical-align: middle; text-align: center"></td>
        <td style="vertical-align: middle; text-align: center; width: 30%">Итого: </td>
        <td style="vertical-align: middle; text-align: center; width: 30%"><?php echo e(number_format($schedule->pluck('amount')->sum(), 0, '.', ' ')); ?> <?php echo e($currency === 'KGS' ? 'сом' : '$'); ?></td>
        <td style="vertical-align: middle; text-align: center; width: 40%"></td>
    </tr>
    </tbody>
</table>
<?php /**PATH D:\Development\Akbar\Projects\apartment-crm-v9\resources\views/templates/schedule-table.blade.php ENDPATH**/ ?>