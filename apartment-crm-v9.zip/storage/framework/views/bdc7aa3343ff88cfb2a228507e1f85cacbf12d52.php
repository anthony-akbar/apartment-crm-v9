<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Akbar\Projects\apartment-crm-v9\resources\views/dashboard/index.blade.php ENDPATH**/ ?>