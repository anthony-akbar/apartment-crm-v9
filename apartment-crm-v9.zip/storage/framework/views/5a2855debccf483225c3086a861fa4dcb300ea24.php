<!-- BEGIN: Data List -->
<div class="intro-y col-span-12 overflow-auto 2xl:overflow-visible">
    <table class="table table-report -mt-2">
        <thead>
        <tr>
            <th class="whitespace-nowrap">№</th>
            <th class="whitespace-nowrap">Ф.И.О.</th>
            <th class="text-center whitespace-nowrap">Статус</th>
            <th class="text-center whitespace-nowrap">Дата окончания</th>
            <th class="whitespace-nowrap">Квартира</th>
            <th class="whitespace-nowrap">Аванс</th>
            <th class="text-center whitespace-nowrap">Действия</th>
        </tr>
        </thead>
        <tbody>

        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="intro-x">
                <td class="w-20 !py-4"><?php echo e($key + 1); ?><a class="whitespace-nowrap"></a></td>
                <td class="w-56">
                    <a href="" class="underline decoration-dotted font-medium whitespace-nowrap"><?php echo e($booking->client->firstname); ?> <?php echo e($booking->client->name); ?></a>
                    <div class="text-slate-500 text-xs whitespace-nowrap mt-0.5"><?php echo e($booking->client->passportId); ?></div>
                </td>
                <td class="text-center">
                    <div class="flex items-center justify-center whitespace-nowrap text-success">
                        <i class="px-1" data-lucide="check-square"></i>
                        <?php echo e($booking->status); ?>

                    </div>
                </td>
                <td class="w-40 !py-4 whitespace-nowrap"><?php echo e(date("d.m.Y", strtotime($booking->until))); ?></td>
                <td>
                    <div class="whitespace-nowrap">№ <?php echo e($booking->apartment->id); ?></div>
                    <div class="text-slate-500 text-xs whitespace-nowrap mt-0.5"><?php echo e($booking->apartment->square); ?> м², <?php echo e($booking->apartment->floor); ?> этаж, <?php echo e($booking->apartment->block); ?> блок, <?php echo e($booking->apartment->rooms); ?> <?php echo e($booking->apartment->rooms === 1 ? 'комната' : 'комнат'); ?></div>
                </td>
                <td class="text-center">
                    <?php echo e(number_format($booking->paid, 0, '.', ' ') ?? '- - - -'); ?>

                </td>
                <td class="table-report__action">
                    <div class="flex justify-center items-center">
                        <a class="flex items-center text-primary whitespace-nowrap mr-5" href="">
                            <i class="px-1" data-lucide="arrow-left-right"></i> Детали </a>
                        <a class="flex items-center text-danger whitespace-nowrap" href="javascript:;"
                           data-tw-toggle="modal" data-tw-target="#delete-confirmation-modal-<?php echo e($booking->id); ?>">
                            <i class="px-1" data-lucide="trash"></i>  Удалить </a>
                    </div>
                </td>
            </tr>
            <!-- BEGIN: Delete Confirmation Modal -->
            <div id="delete-confirmation-modal-<?php echo e($booking->id); ?>" class="modal" tabindex="-1" aria-hidden="true" style="">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-body p-0">
                            <div class="p-5 text-center">
                                <i data-lucide="x-circle" class="w-16 h-16 text-danger mx-auto mt-3"></i>
                                <div class="text-3xl mt-5">Are you sure?</div>
                                <div class="text-slate-500 mt-2">
                                    Do you really want to delete these records?
                                    <br>
                                    This process cannot be undone.
                                </div>
                            </div>
                            <div class="px-5 pb-8 text-center">
                                <form method="post" action="">
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>
                                    <a type="button" data-tw-dismiss="modal" class="btn btn-outline-secondary w-24 mr-1">Cancel</a>
                                    <button type="submit" class="btn btn-danger w-24">Delete</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END: Delete Confirmation Modal -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>
<!-- END: Data List -->
<!-- BEGIN: Pagination -->
<div class="intro-y col-span-12 flex flex-wrap sm:flex-row sm:flex-nowrap items-center">

    <div class="grid grid-cols-2">
        <div class="mt-10 grid-cols-1 text-center">
            
        </div>
    </div>

    
    <select class="w-20 form-select box mt-3 sm:mt-0">
        <option>10</option>
        <option>25</option>
        <option>35</option>
        <option>50</option>
    </select>
</div>
<!-- END: Pagination -->
<?php /**PATH D:\Development\Akbar\Projects\apartment-crm-v9\resources\views/booking/apartments/table.blade.php ENDPATH**/ ?>