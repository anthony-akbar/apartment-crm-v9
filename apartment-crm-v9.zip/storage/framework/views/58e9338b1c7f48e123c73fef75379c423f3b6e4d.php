<?php $__currentLoopData = array_unique($apartments->pluck('floor')->toArray()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $floor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="intro-x">
        <div id="faq-accordion-<?php echo e($floor); ?>" class="accordion my-5">
            <div class="accordion-item intro-x my-10">
                <div id="faq-accordion-content-<?php echo e($floor); ?>" class="accordion-header">
                    <button class="accordion-button text-center <?php echo e($key !== 0 ? "collapsed" : ""); ?>" type="button"
                            data-tw-toggle="collapse"
                            data-tw-target="#faq-accordion-collapse-<?php echo e($floor); ?>" aria-expanded="true"
                            aria-controls="faq-accordion-collapse-<?php echo e($floor); ?>"> <?php echo e($floor); ?> - Этаж
                    </button>
                </div>
                <div id="faq-accordion-collapse-<?php echo e($floor); ?>"
                     class="accordion-collapse collapse <?php echo e($key === 0 ? "show" : ""); ?>"
                     aria-labelledby="faq-accordion-content-<?php echo e($floor); ?>" data-tw-parent="#faq-accordion-<?php echo e($floor); ?>">
                    <div class="accordion-body text-slate-600 dark:text-slate-500 leading-relaxed">
                        <table class="table table-report my-auto">
                            <?php $__currentLoopData = $apartments->where('floor', $floor); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="intro-x box cursor-pointer" data-tw-toggle="modal"
                                    data-tw-target="#apartment-<?php echo e($apartment->id); ?>">
                                    <td class="text-center   w-20">
                                        <a href="javascript:;" data-tw-toggle="modal"
                                           data-tw-target="#apartment-<?php echo e($apartment->id); ?>"><?php echo e($apartment->number); ?>

                                        </a>
                                    </td>
                                    <td class="text-center text-center w-40"><?php echo e($apartment->rooms); ?></td>
                                    <td class="text-center w-40"><?php echo e($apartment->floor); ?> этаж</td>
                                    <td class="text-center w-40"><?php echo e($apartment->square); ?> м²</td>
                                    <td class="text-center w-40"><?php echo e($apartment->block); ?> блок</td>
                                    <td class="text-center w-56"><?php echo e(number_format($apartment->price, 0, '.', ' ')); ?> <?php echo e($apartment->currency); ?></td>
                                    <td class="text-center w-40"><?php echo e(number_format($apartment->total, 0, '.', ' ')); ?> <?php echo e($apartment->currency); ?></td>
                                    <td class="w-56 <?php if($apartment->staus === 4): ?> text-success <?php elseif($apartment->status === 2): ?> text-warning
                                    <?php elseif($apartment->status === 1): ?> text-success <?php elseif($apartment->status === 3): ?> text-danger
                                       <?php endif; ?> text-center">
                                        <?php if($apartment->staus === 4): ?>
                                            Свободно
                                        <?php elseif($apartment->status === 2): ?>
                                            <i class="inline-block px-1" data-lucide="tag"></i>Забронировано
                                        <?php elseif($apartment->status === 1): ?>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                 viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                                 stroke-linecap="round" stroke-linejoin="round" icon-name="check-square"
                                                 class="lucide lucide-check-square inline-block px-1"
                                                 data-lucide="check-square">
                                                <polyline points="9 11 12 14 22 4"></polyline>
                                                <path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"></path>
                                            </svg>Свободно
                                        <?php elseif($apartment->status === 3): ?>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                 viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                                 stroke-linecap="round" stroke-linejoin="round" icon-name="x-square"
                                                 class="lucide lucide-x-square inline-block px-1"
                                                 data-lucide="x-square">
                                                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                                                <line x1="9" y1="9" x2="15" y2="15"></line>
                                                <line x1="15" y1="9" x2="9" y2="15"></line>
                                            </svg>Продано
                                        <?php endif; ?>
                                    </td>

                                </tr>
                                <!-- BEGIN: Modal Content -->
                                <div id="apartment-<?php echo e($apartment->id); ?>" class="modal" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-xl">
                                        <div class="modal-content">
                                            <div class="modal-body p-5 text-center">
                                                <div class="intro-y px-3 pt-5 mt-5">
                                                    <div class="flex flex-col lg:flex-row pb-5 -mx-5">
                                                        <div
                                                            class="flex flex-1 px-5 items-center justify-center lg:justify-start">
                                                            <img src="<?php echo e(asset($apartment->image)); ?>" data-action="zoom"
                                                                 data-tw-toggle="modal"
                                                                 data-tw-target="#apartment-<?php echo e($apartment->id); ?>">
                                                        </div>
                                                        <div
                                                            class="mt-6 lg:mt-0 flex-1 px-3 border-l border-slate-200/60 dark:border-darkmode-400 pt-5 lg:pt-0">
                                                            <div
                                                                class="font-medium text-3xl text-center lg:text-left lg:mt-3">
                                                                Квартира
                                                                №<?php echo e($apartment->number); ?></div>
                                                            <div class="px-5 py-3 flex flex-col justify-center flex-1">
                                                                <div class="grid grid-cols-2 pt-3">
                                                                    <div class="grid-cols-1 px-3">
                                                                        <div class="text-left text-slate-500 text-xs">
                                                                            ПЛОЩАДЬ
                                                                        </div>
                                                                        <div class="mt-1.5 flex items-center">
                                                                            <div
                                                                                class="text-base"><?php echo e($apartment->square); ?>

                                                                                м²
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="text-left text-slate-500 text-xs mt-5">
                                                                            ЭТАЖ
                                                                        </div>
                                                                        <div class="mt-1.5 flex items-center">
                                                                            <div
                                                                                class="text-base"><?php echo e($apartment->floor); ?></div>
                                                                        </div>
                                                                        <div
                                                                            class="text-left text-slate-500 text-xs mt-5">
                                                                            ЦЕНА ЗА м²
                                                                        </div>
                                                                        <div class="mt-1.5 flex items-center">
                                                                            <div
                                                                                class="text-base"><?php echo e(number_format($apartment->price, 0, '.', ' ')); ?> <?php echo e($apartment->currency); ?></div>
                                                                        </div>

                                                                        <div
                                                                            class="text-left text-slate-500 text-xs mt-5 pr-3">
                                                                            СТАТУС
                                                                        </div>
                                                                        <div class="mt-2">
                                                                            <select id="status-select"
                                                                                    onchange="redirect(this, <?php echo e($apartment->id); ?>)"
                                                                                    class="tom-select w-full">
                                                                                <option
                                                                                    value="1" <?php echo e($apartment->status === 1 ? 'selected="true"' : ''); ?>>
                                                                                    СВОБОДНО
                                                                                </option>
                                                                                <option
                                                                                    value="2" <?php echo e($apartment->status === 2 ? 'selected="true"' : ''); ?>>
                                                                                    БРОНЬ
                                                                                </option>
                                                                                <option
                                                                                    value="3" <?php echo e($apartment->status === 3 ? 'selected="true"' : ''); ?>>
                                                                                    ПРОДАНО
                                                                                </option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="grid-cols-1 px-3">
                                                                        <div class="text-left text-slate-500 text-xs">
                                                                            ПЛАНИРОВКА КВАРТИРЫ
                                                                        </div>
                                                                        <div class="mt-1.5 flex items-center">
                                                                            <div
                                                                                class="text-base"><?php echo e($apartment->rooms); ?>

                                                                                комнат<?php echo e($apartment->rooms === 1 ? 'а' : ''); ?></div>
                                                                        </div>
                                                                        <div
                                                                            class="text-left text-slate-500 text-xs mt-5">
                                                                            БЛОК
                                                                        </div>
                                                                        <div class="mt-1.5 flex items-center">
                                                                            <div
                                                                                class="text-base"><?php echo e($apartment->block ?? '1'); ?></div>
                                                                        </div>
                                                                        <div
                                                                            class="text-left text-slate-500 text-xs mt-5">
                                                                            СТОИМОСТЬ
                                                                        </div>
                                                                        <div class="mt-1.5 flex items-center">
                                                                            <div
                                                                                class="text-left text-base"><?php echo e(number_format($apartment->total ?? 0, 0, '.', ' ')); ?> <?php echo e($apartment->currency); ?></div>
                                                                        </div>
                                                                        <?php if($apartment->client !== null): ?>
                                                                            <div
                                                                                class="text-left text-slate-500 text-xs mt-5">
                                                                                КЛИЕНТ
                                                                            </div>
                                                                            <div class="mt-1.5 flex items-center">
                                                                                <div
                                                                                    class="text-left text-base"><?php echo e($apartment->client->firstname . ' ' . $apartment->client->name ?? '- - - -'); ?></div>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </div>

                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- END: Modal Content -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\Development\Akbar\Projects\apartment-crm-v9\resources\views/apartments/table.blade.php ENDPATH**/ ?>