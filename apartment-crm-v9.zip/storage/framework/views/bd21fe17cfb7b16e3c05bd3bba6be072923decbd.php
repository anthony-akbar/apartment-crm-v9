<?php $__env->startSection('content'); ?>

    <div class="intro-y flex flex-col sm:flex-row items-center p-10">
        <h2 class="text-lg font-medium mr-auto">Экспорт</h2>
    </div>

    <div class="grid grid-cols-2 mx-auto">

        <div class="grid-cols-1 mx-3">
            <select id="tables" name="tables" data-placeholder="Select your favorite actors" class="tom-select w-full" multiple>
                <option value="apartments" selected>Квартиры</option>
                <option value="apt_contracts">Договора</option>
                <option value="clients" selected>Клиенты</option>
                <option value="payments">Оплаты</option>
            </select>
        </div>
        <div class="grid-cols-1 mx-3">

            <select id="data" data-placeholder="Select your favorite actors" class="tom-select w-full" multiple>
                <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e('client$' . $key); ?>"><?php echo e($key); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $apartment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e('apartment$' . $key); ?>"><?php echo e($key); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

    </div>

    <div id="table_result">
    </div>

    <button id="export" class="btn btn-primary mt-5">Export</button>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>

        function onDataChange() {
            let tables = $('#tables').val()
            let data = $('#data').val()
            console.log(tables)
            console.log(data)

            $.ajax({

                url: '<?php echo e(route('export.query')); ?>',
                data: {
                    'data': {
                        tables,
                        data
                    }
                },
                type: 'GET',
                success: function (data) {
                    $('#table_result').html(data)
                }
            })
        }

        function exsport() {
            let tables = $('#tables').val()
            let data = $('#data').val()

            console.log(JSON.stringify(tables.toString(), data.toString()))
            window.location.replace( '<?php echo e(route('export.export')); ?>' + '?data=' + tables + data);

        }

        $('#export').click(exsport)
        $('#tables').change(onDataChange)
        $('#data').change(onDataChange)

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Akbar\Projects\apartment-crm-v9\resources\views/export/index.blade.php ENDPATH**/ ?>