<?php if(count($clients) !== 0 || count($contracts) !== 0 || count($payments) !== 0): ?>

    <div class="search-result__content">

        <?php if(count($clients) !== 0): ?>
            <div class="search-result__content__title">Клиенты</div>
            <div class="mb-5">
                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="" class="flex items-center mt-2">
                        <div class="w-8 h-8 image-fit">
                            <img alt="Midone - HTML Admin Template" class="rounded-full"
                                 src="<?php echo e(asset('dist/images/profile-15.jpg')); ?>">
                        </div>
                        <div
                            class="ml-3"><?php echo e($client->firstname); ?> <?php echo e($client->name); ?> <?php echo e($client->fathersname ?? ''); ?></div>
                        <div class="ml-auto w-48 truncate text-slate-500 text-xs text-right"><?php echo e($client->phone); ?></div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <?php if(count($contracts) !== 0): ?>

            <div id="search-results-clients">
                <div class="search-result__content__title">Договоры</div>
                <div class="mb-5">

                    <?php $__currentLoopData = $contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="" class="flex items-center">
                                <i class="w-4 h-4" data-lucide="file-text"></i>
                            <div class="ml-3">№ <?php echo e($contract['id']); ?></div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        <?php endif; ?>

    </div>

<?php else: ?>
    <div class="search-result__content hidden"></div>
<?php endif; ?>
<?php /**PATH D:\Development\Akbar\Projects\apartment-crm-v9\resources\views/sections/search-results.blade.php ENDPATH**/ ?>