<?php $__env->startSection('content'); ?>

    <h2 class="intro-y text-lg font-medium mt-10">Клиенты</h2>
    <div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-2">
        <a href="<?php echo e(route('clients.create')); ?>" class="btn btn-primary shadow-md mr-2">Добавить клиента</a>
        <div class="dropdown">
            <button class="dropdown-toggle btn px-2 box" aria-expanded="false" data-tw-toggle="dropdown">
                <span class="w-5 h-5 flex items-center justify-center">
                <i data-lucide="plus"></i>
                </span>
            </button>
            <div class="dropdown-menu w-40">
                <ul class="dropdown-content">
                    <li>
                        <a href="" class="dropdown-item">
                            <i class="px-1" data-lucide="printer"></i> Print </a>
                    </li>
                    <li>
                        <a href="" class="dropdown-item">
                            <i class="px-1" data-lucide="file-text"></i>
                            Export to Excel </a>
                    </li>
                    <li>
                        <a href="" class="dropdown-item">
                            <i class="px-1" data-lucide="file-text"></i>
                            Export to PDF </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="hidden md:block mx-auto text-slate-500">Клиенты <?php echo e($clients->count()); ?> из <?php echo e($clients->count()); ?></div>
        <div class="w-full sm:w-auto mt-3 sm:mt-0 sm:ml-auto md:ml-0">
            <div class="w-56 relative text-slate-500">
                <input type="text" class="form-control w-56 box pr-10" placeholder="Поиск...">
                <i class="w-4 h-4 absolute my-auto inset-y-0 mr-3 right-0" data-lucide="search"></i>
            </div>
        </div>
    </div>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <?php echo $__env->make('clients.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Akbar\Projects\apartment-crm-v9\resources\views/clients/index.blade.php ENDPATH**/ ?>