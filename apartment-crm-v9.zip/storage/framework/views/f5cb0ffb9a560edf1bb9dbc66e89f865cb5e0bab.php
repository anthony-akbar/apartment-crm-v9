
<div class="mt-5 box intro-x overflow-scroll">
<table class="table" style="border: 1px solid black; vertical-align: middle; text-align: center">
    <thead>
    <tr style="border: 1px solid black; vertical-align: middle; text-align: center">
        <?php $__currentLoopData = $keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th style="border: 1px solid black; vertical-align: middle; text-align: center" class="whitespace-nowrap">
                <?php if(str_contains($item, 'client$')): ?>
                    <?php echo e(str_replace('client$', '', $item)); ?>

                <?php elseif(str_contains($item, 'apartment$')): ?>
                    <?php echo e(str_replace('apartment$', '', $item)); ?>

                <?php endif; ?>
            </th>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tr>
    </thead>
    <tbody>

    <?php for($i = 0; $i < count($contract_array); $i++): ?>
        <tr style="border: 1px solid black; vertical-align: middle; text-align: center">
            <?php $__currentLoopData = $keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($contract_array[$i][explode('$', $item)[0]][explode('$', $item)[1]]); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    <?php endfor; ?>


    
    </tbody>
</table>
</div>
<?php /**PATH D:\Development\Akbar\Projects\apartment-crm-v9\resources\views/export/table_result.blade.php ENDPATH**/ ?>