<label class="form-label">Договор</label>
<div class="mt-2 w-full">
    <select name="contract_id" id="contract_id" onchange="onContractChange()" class="form-control tom-select">
        <?php $__currentLoopData = $contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e($key === 0 ? 'selected="true"' : ''); ?> value="<?php echo e($contract->id); ?>">
                <a href="" class="underline decoration-dotted font-medium whitespace-nowrap">№<?php echo e($contract->id); ?> <?php echo e($contract->client->firstname); ?> <?php echo e($contract->client->name); ?></a>
                <div class="text-slate-500 text-xs whitespace-nowrap mt-0.5">AN4063060</div>
            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<?php /**PATH D:\Development\Akbar\Projects\apartment-crm-v9\resources\views/payments/contract-selector.blade.php ENDPATH**/ ?>