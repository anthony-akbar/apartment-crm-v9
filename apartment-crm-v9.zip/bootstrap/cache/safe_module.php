<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Safe\\Providers\\SafeServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Safe\\Providers\\SafeServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);