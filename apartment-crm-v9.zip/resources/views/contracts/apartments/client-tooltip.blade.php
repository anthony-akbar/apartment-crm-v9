@foreach($clients as $client)

@endforeach
