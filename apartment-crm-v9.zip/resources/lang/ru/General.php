<?php

return array (
  'booking' => 'Бронирование',
);
